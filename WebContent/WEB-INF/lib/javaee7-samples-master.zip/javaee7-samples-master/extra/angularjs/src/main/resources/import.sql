insert into note (id,title,summary) values (nextval('hibernate_sequence'),'Hello','First note');
insert into note (id,title,summary) values (nextval('hibernate_sequence'),'Good bye','Another note');
